import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { KILROYCONSTANT } from '../constants';

const BASE_URL = environment.nepal_corona_url;

@Injectable({
  providedIn: 'root',
})
export class NepalCoronaService {
  protected httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/JSON',
    }),
  };

  NCIurl = KILROYCONSTANT;
  constructor(private http: HttpClient) {}

  getNepalTestingSummaryData(): Observable<any> {
    return this.http.get(`${BASE_URL}${this.NCIurl.nepalTestingSummary}`);
    // .pipe(retry(1), catchError(this.errorHandle));
  }

  getNepalDetailedCasesSummaryData(): Observable<any> {
    return this.http.get(`${BASE_URL}${KILROYCONSTANT.detailedCasesSummary}`);
  }

  errorHandle({ error }) {
    if (error.error && error.message) {
      return throwError(error.message);
    }
  }
}
