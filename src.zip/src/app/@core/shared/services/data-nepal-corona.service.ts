import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserInterface } from '../interface/user.interface';
import { environment } from '../../../../environments/environment';
import { KILROYCONSTANT, AUTHCONSTANTS } from '../constants';

const BASE_URL = environment.data_nepal_corona_url;

@Injectable({
  providedIn: 'root',
})
export class DataNepalCoronaService {
  constructor(private http: HttpClient) {}

  protected httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/JSON',
    }),
  };

  getNepalCaseSummary() {
    return this.http.get(
      BASE_URL + KILROYCONSTANT.caseSummary,
      this.httpOptions
    );
  }
}
