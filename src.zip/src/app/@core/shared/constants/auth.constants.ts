export const AUTHCONSTANTS = {
  ACCESS_TOKEN: 'token',
};
