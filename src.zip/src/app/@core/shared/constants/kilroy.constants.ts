export const KILROYCONSTANT = {
  signupUrl: 'api/signup',
  loginurl: 'auth/login/',

  // Nepal-Corona-services-url
  nepalTestingSummary: 'data/nepal',
  caseSummary: 'covid/summary',
};

export const NepalCoronaInfoUrlConstant = {
  nepalTestingSummary: 'data/nepal',
};
export const DataNepalCoronaInfoUrlConstant = {
  detailedCasesSummary: 'covid/summary',
};
