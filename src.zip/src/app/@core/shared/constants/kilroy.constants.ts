export const KILROYCONSTANT = {
  signupUrl: 'api/signup',
  loginurl: 'auth/login/',

  // Nepal-Corona-services-url
  nepalTestingSummary: 'data/nepal',
  caseSummary: 'covid/summary',

  // data Corona info
  detailedCasesSummary: '/api/',
};
