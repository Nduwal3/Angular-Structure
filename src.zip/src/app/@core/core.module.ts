import { NgModule } from '@angular/core';
import { AuthService } from './shared/services/auth.service';
import { HttpClientModule } from '@angular/common/http';
import {
  GuestGuardService,
  NepalCoronaService,
  DataNepalCoronaService,
} from './shared/services';

const SERVICES = [
  AuthService,
  GuestGuardService,
  NepalCoronaService,
  DataNepalCoronaService,
];

@NgModule({
  declarations: [],
  imports: [HttpClientModule],
  providers: [...SERVICES],
  //   exports: [...SERVICES],
})
export class CoreModule {}
