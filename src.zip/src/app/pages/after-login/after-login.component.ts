import { Component } from '@angular/core';

@Component({
  selector: 'app-after-login',
  template: '<app-sidenav></app-sidenav>',
})
export class AfterLoginComponent {}
