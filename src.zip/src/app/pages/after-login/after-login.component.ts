import { Component } from '@angular/core';

@Component({
  selector: 'app-after-login',
  template: '<app-header></app-header><app-sidenav></app-sidenav>',
})
export class AfterLoginComponent {}
