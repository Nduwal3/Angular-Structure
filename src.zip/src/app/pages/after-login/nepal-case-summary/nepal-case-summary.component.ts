import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nepal-case-summary',
  templateUrl: './nepal-case-summary.component.html',
  styleUrls: ['./nepal-case-summary.component.scss'],
})
export class NepalCaseSummaryComponent implements OnInit {
  ncsData: any;

  constructor() {}

  ngOnInit(): void {}
}
