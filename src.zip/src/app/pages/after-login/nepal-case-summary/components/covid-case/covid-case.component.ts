import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { NepalCaseSummaryService } from '../../services/nepal-case-summary.service';

@Component({
  selector: 'app-covid-case',
  templateUrl: './covid-case.component.html',
  styleUrls: ['./covid-case.component.scss'],
})
export class CovidCaseComponent implements OnChanges {
  @Input() caseData;
  constructor(private NCSD: NepalCaseSummaryService) {}

  ngOnChanges(): void {
    // this.provinceCaseSummary = this.NCSD.filterDataByCovid(
    //   this.provinceData,
    //   'province'
    // );
  }
}
