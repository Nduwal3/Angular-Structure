import { Component } from '@angular/core';

@Component({
  selector: 'app-before-login',
  template: '<app-header></app-header><router-outlet></router-outlet>',
})
export class BeforeLoginComponent {}
