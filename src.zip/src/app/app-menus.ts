export const MENU_ITEMS = [
  {
    text: 'Profile',
    path: '/user/profile',
  },
  {
    text: 'Dashboard',
    path: '/user/dashboard',
  },
  {
    text: 'Feed',
    path: '/user/feed',
  },
  {
    text: 'Nepal Cases Summary',
    path: '/user/nepal-cases-summary',
  },
  // {
  //     text:'Login',
  //     path:'login/'
  // },
];
